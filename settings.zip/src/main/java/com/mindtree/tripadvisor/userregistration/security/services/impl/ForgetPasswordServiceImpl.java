package com.mindtree.tripadvisor.userregistration.security.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.userregistration.entity.ForgetPassword;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.exception.NoSuchEmailFFoundException;
import com.mindtree.tripadvisor.userregistration.exception.NoSuchUserNameExist;
import com.mindtree.tripadvisor.userregistration.exception.UserRegistractionException;
import com.mindtree.tripadvisor.userregistration.exception.WrongUserNameException;
import com.mindtree.tripadvisor.userregistration.repository.ForgetPasswordRepository;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;
import com.mindtree.tripadvisor.userregistration.security.services.ForgetPasswordService;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@Service
public class ForgetPasswordServiceImpl implements ForgetPasswordService {

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	UserRepository userRepository;

	@Autowired
	ForgetPasswordRepository forgetPasswordRepository;

	int otp = 0;
	private JavaMailSender javaMailSender;

	@Autowired
	public ForgetPasswordServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public int sendEmail(String email) throws MailException, UserRegistractionException {

		otp = (int) getToken();

		SimpleMailMessage mail = new SimpleMailMessage();
		mail.setTo(email);
		mail.setSubject("Testing Mail API");
		mail.setText("Hurray ! You have done that dude..." + otp);

		ForgetPassword forgetPassword = new ForgetPassword(email, otp);
		javaMailSender.send(mail);
		forgetPasswordRepository.save(forgetPassword);
		return otp;
	}

	private double getToken() {

		return (Math.random() * ((9999 - 1000) + 1));
	}

	@Override
	public String updatePassword(User user) throws UserRegistractionException {
		System.out.println(user.getUsername());
		System.out.println("i am in update");
		User result = userRepository.findByUsername(user.getUsername())
				.orElseThrow(() -> new NoSuchUserNameExist("Wrong username"));
		
		User resulttnew =userRepository.findByEmail(user.getEmail()).orElseThrow(()->new NoSuchEmailFFoundException("no email"));
		System.out.println(result.getName());
		System.out.println("hii");
		System.out.println(resulttnew.getName());
		System.out.println(user.getEmail());
		System.out.println(result.getEmail());
		if (user.getEmail().equalsIgnoreCase(result.getEmail())) {
			result.setUsername(user.getUsername());
			result.setPassword(encoder.encode(user.getPassword()));

			if (userRepository.save(result) != null) {
				return "Password updated successfully!";
			}
		} else {
			throw new WrongUserNameException("wrong username");
		}

		return null;

	}
}
