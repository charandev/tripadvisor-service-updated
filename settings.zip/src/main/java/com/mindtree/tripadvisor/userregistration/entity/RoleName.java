package com.mindtree.tripadvisor.userregistration.entity;

public enum  RoleName {
    ROLE_USER,
    ROLE_PM,
    ROLE_ADMIN
}