package com.mindtree.tripadvisor.searchhotel.dto;

public class HotelDto {

}
