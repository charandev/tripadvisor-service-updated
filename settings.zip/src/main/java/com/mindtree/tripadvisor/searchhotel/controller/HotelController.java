/**
 * 
 */
package com.mindtree.tripadvisor.searchhotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.tripadvisor.searchhotel.entity.Hotel;
import com.mindtree.tripadvisor.searchhotel.service.HotelService;

/**
 * @author M1056135
 *
 */
@RestController
@CrossOrigin
public class HotelController {
	
	@Autowired
	HotelService hotelService;
	@GetMapping("/gethotelsbasedoncity")
	public List<Hotel> getHotelBasedOnPlace(@RequestParam String place){
		return hotelService.getHotelBasedOnPlace(place);
		
	}

}
