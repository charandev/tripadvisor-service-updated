package com.mindtree.tripadvisor.searchflight.dto;

public class FlightDto {

}
