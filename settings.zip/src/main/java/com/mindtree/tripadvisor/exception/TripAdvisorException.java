package com.mindtree.tripadvisor.exception;

public class TripAdvisorException {

}
