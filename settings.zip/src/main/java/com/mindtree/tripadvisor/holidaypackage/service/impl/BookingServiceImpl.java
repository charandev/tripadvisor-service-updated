package com.mindtree.tripadvisor.holidaypackage.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.holidaypackage.entity.Booking;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.repository.BookingRepository;
import com.mindtree.tripadvisor.holidaypackage.repository.HolidayPackageRepository;
import com.mindtree.tripadvisor.holidaypackage.service.BookingService;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;
@Service
public class BookingServiceImpl implements BookingService {
	
	
	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	HolidayPackageRepository holidayPackageRepository;
	
	@Autowired
	UserRepository userRepository;
	
private JavaMailSender javaMailSender;
User user;
	Booking bookingResult;
	HolidayPackage holidayPackage;
	@Autowired
	public BookingServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	
	@Override
	public String bookNow(LocalDate date, int packageId, Long userId) {
		
		
		user=userRepository.findById(userId).get();
		holidayPackage=holidayPackageRepository.findById(packageId).get();
		Booking booking=new Booking(holidayPackage, user, date);
		
		bookingResult=bookingRepository.save(booking);
		if(booking!=null)
		{
			sendEntrymail(user.getEmail());
			return "Booking Sucessfully";
		}
		
		
		return "Unsucessfully";
	}

	
	

private void sendEntrymail(String email) {
	
	SimpleMailMessage mail = new SimpleMailMessage();
	mail.setTo(email);
	mail.setSubject("TripAdvisor");
	mail.setText("Dear "+user.getName()+"\n"+"Booking sucessfully booking id:"+bookingResult.getBookingId()+""
			+ "\n"+"Your Package Details\n Name:"+holidayPackage.getPackage_name()+""
					+ "\n Budget:"+holidayPackage.getBudget()+""
							+ "\n Days and nights:"+holidayPackage.getDays()+"D and "+holidayPackage.getNights()+"N");
	
	javaMailSender.send(mail);
	
}

	
	

	@Override
	public String deleteBooking(int bookingId) {
		bookingRepository.deleteById(bookingId);
		return "Sucessfully";
	}

}
