package com.mindtree.tripadvisor.holidaypackage.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.tripadvisor.holidaypackage.service.BookingService;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;

@RestController
@RequestMapping("booking")
@CrossOrigin
public class BookingController {

	
	
	@Autowired
	BookingService bookingService;
	
	@Autowired
	UserRepository userRepository;
	
	@PostMapping("/bookNow/{packageId}/{userId}/{date}")
	public String bookNow(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)LocalDate date,@PathVariable int packageId,@PathVariable Long userId)
	{
		System.out.println(date);
		return bookingService.bookNow(date,packageId,userId);
	}
	
	
	
	
	@PostMapping("/deleteBooking/{bookingId}")
	public String deleteBooking(@PathVariable int bookingId)
	{
		
		return bookingService.deleteBooking(bookingId);
	}
	
	
}
