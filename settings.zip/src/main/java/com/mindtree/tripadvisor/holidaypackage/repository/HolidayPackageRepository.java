package com.mindtree.tripadvisor.holidaypackage.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;


@Repository
public interface HolidayPackageRepository extends JpaRepository<HolidayPackage, Integer> {

}
