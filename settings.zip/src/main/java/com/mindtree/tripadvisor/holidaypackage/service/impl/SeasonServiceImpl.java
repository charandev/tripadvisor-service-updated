package com.mindtree.tripadvisor.holidaypackage.service.impl;

import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.holidaypackage.service.SeasonService;

@Service
public class SeasonServiceImpl  implements SeasonService{

}
