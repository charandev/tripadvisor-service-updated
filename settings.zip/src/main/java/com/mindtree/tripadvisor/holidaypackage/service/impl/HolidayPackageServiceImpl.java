package com.mindtree.tripadvisor.holidaypackage.service.impl;

import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.holidaypackage.service.HolidayPackageService;

@Service
public class HolidayPackageServiceImpl implements HolidayPackageService {

}
