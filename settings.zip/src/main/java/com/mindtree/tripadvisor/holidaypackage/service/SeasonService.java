package com.mindtree.tripadvisor.holidaypackage.service;

public interface SeasonService {

}
