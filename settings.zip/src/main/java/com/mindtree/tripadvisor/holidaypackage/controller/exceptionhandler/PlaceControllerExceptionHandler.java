package com.mindtree.tripadvisor.holidaypackage.controller.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.tripadvisor.holidaypackage.controller.PlaceController;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayException;
import com.mindtree.tripadvisor.holidaypackage.exception.HolidayPackageException;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;

@RestControllerAdvice(assignableTypes = {PlaceController.class})
public class PlaceControllerExceptionHandler {

	@ExceptionHandler(HolidayPackageException.class)
	public ResponseEntity<HolidayException>  exceptionHandler(PlaceNotFoundException e, Throwable cause){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new HolidayException(e.getMessage()));
	}
}



