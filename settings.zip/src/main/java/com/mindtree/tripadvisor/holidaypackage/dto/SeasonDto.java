package com.mindtree.tripadvisor.holidaypackage.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;

public class SeasonDto {

	private int seasonId;
	private String seasonType;
	private String startingMonth;
	private String endingMonth;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="seasons")
	private List<PlaceDto> places;
	public int getSeason_id() {
		return seasonId;
	}
	public void setSeason_id(int season_id) {
		this.seasonId = season_id;
	}
	public String getSeason_type() {
		return seasonType;
	}
	public void setSeason_type(String season_type) {
		this.seasonType = season_type;
	}
	public String getStarting_month() {
		return startingMonth;
	}
	public void setStarting_month(String starting_month) {
		this.startingMonth = starting_month;
	}
	public String getEnding_month() {
		return endingMonth;
	}
	public void setEnding_month(String ending_month) {
		this.endingMonth = ending_month;
	}
	public List<PlaceDto> getPlaces() {
		return places;
	}
	public void setPlaces(List<PlaceDto> places) {
		this.places = places;
	}
	@Override
	public String toString() {
		return "Season [season_id=" + seasonId + ", season_type=" + seasonType + ", starting_month=" + startingMonth
				+ ", ending_month=" + endingMonth + ", places=" + places + "]";
	}
	public SeasonDto(int season_id, String season_type, String starting_month, String ending_month, List<PlaceDto> places) {
		super();
		this.seasonId = season_id;
		this.seasonType = season_type;
		this.startingMonth = starting_month;
		this.endingMonth = ending_month;
		this.places = places;
	}
	public SeasonDto() {
		super();	
	}

}
