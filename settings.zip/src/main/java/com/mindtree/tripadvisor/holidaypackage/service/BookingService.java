package com.mindtree.tripadvisor.holidaypackage.service;

import java.time.LocalDate;

public interface BookingService {

	String bookNow(LocalDate date, int packageId, Long userId);

	String deleteBooking(int bookingId);

}
