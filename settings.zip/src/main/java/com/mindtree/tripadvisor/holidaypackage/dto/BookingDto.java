package com.mindtree.tripadvisor.holidaypackage.dto;

import java.time.LocalDate;

import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.userregistration.dto.UserDto;

public class BookingDto {

	private int bookingId;

	private HolidayPackage holidayPackage;

	private UserDto user;

	private LocalDate date;

	public BookingDto(HolidayPackage holidayPackage, UserDto user, LocalDate date) {
		super();
		this.holidayPackage = holidayPackage;
		this.user = user;
		this.date = date;
	}

	public BookingDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public HolidayPackage getHolidayPackage() {
		return holidayPackage;
	}

	public void setHolidayPackage(HolidayPackage holidayPackage) {
		this.holidayPackage = holidayPackage;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

}
